import java.util.*;
import java.text.DecimalFormat;
import java.util.Hashtable;
class Solution {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = Integer.parseInt(sc.nextLine());
		Solution sol = new Solution();
		Score[] score = new Score[n];
		Insertion ins = new Insertion();
		Double[] per = new Double[n];
        //BinarySearch bs = new BinarySearch();
		ArrayList<Score> arrli = new ArrayList<Score>();
		for (int i=0; i < n ; i++) {
			String[] s = sc.nextLine().split(",");
			//System.out.println(Arrays.toString(s));
			score[i] = new Score(Integer.parseInt(s[0]), Double.parseDouble(s[1]));
			
		}
		score = ins.sort(score, n);
		
		for (int i = 0; i < n; i++) {
			arrli.add(score[i]);

		
		}
        for (int i = 0 ; i < n; i++ ) {
            per[i] = arrli.get(i).getMarks();
        }
       //System.out.println(Arrays.toString(per));
		int m = Integer.parseInt(sc.nextLine());
		for (int i = 0; i < m ; i++) {
			int number = Integer.parseInt(sc.nextLine());
			for (int j = 0; j < arrli.size(); j++ ) {
				if (arrli.get(j).getRoll() == number ) {
					int index = j;
					Double marks1 = arrli.get(j).getMarks();
					//System.out.println(marks1);
					int start = 0;
					int temp = index;
					while(index >= 0 &&  per[index].compareTo(marks1) == 0){
						start = index;
						index--;
					}
					Double answer = sol.avgCal(per, start, n);
					
					String answer1 = String.valueOf(answer);
					if (answer1.charAt(3) == '0' || answer1.charAt(4) == '0' ) {
						System.out.println(answer1);
					} else {
						 String numberAsString = String.format ("%.2f", answer);
                System.out.println(numberAsString); 
					}
					

				}
				
			}

		}

	}
	Double avgCal(Double[] arr, int start, int n){
		Double n1 =Double.valueOf(n);
		Double start1 = Double.valueOf(start);
		double answer = 100 * (n1 - start1) / n1;

		return answer;
	}
}
class Insertion{
	Insertion(){

	}
	Score[] sort(Score[] list, int n){
		for (int i = 1; i< n; i++) {
			Score key = list[i];
			int j = i-1;
			while(j>=0 && list[j].compareTo(key) < 0){
				list[j+1] = list[j];
				j = j-1;
			}
			list[j+1] = key;
		}
		return list;
	}
}
class Score {
	int roll;
	Double marks;
	Score(int r, Double m){
		this.roll = r;
		this.marks = m;
	}
	int getRoll(){
	  return this.roll;
	}
	Double getMarks(){
		return this.marks;
	}
	int compareTo(Score that){
		if (this.getMarks() > that.getMarks()) {
			return 1;
		}else if(this.getMarks() > that.getMarks()) {
			return -1;
		} else if (this.getMarks() == that.getMarks()) {
				System.out.println("entering marks");
				if(this.getRoll() > that.getRoll()) {
					return 1;
				} else {
					return -1;
				}
				
			
		}
		return -1;
	}
	public String print(){
		return this.getRoll()+","+this.getMarks();
	}
}